﻿namespace HouseFlowPart1.Models
{
    public class RegisterViewModel
	{

        public string Email { get; set; } = "";

        public string Password { get; set; } = "";
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";
    }
}

